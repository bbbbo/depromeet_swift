//
//  main.swift
//  DataStruct
//
//  Created by Jung seoung Yeo on 2017. 10. 28..
//  Copyright © 2017년 Jung seoung Yeo. All rights reserved.
//

import Foundation

var stack = Stack<Any>()
var queue = Queue<Any>()

